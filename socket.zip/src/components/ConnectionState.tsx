import React from 'react';

export function ConnectionState({ isConnected }:any) {
  return <p>State: { '' + isConnected }</p>;
}